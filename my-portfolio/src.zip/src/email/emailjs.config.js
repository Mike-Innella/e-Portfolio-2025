// emailjs.js

const emailjsConfig = {
  serviceId: "service_mygmail",
  templateId: "template_dfltemailtemp",
  publicKey: "cePFoU8dvsaDAlAyz",
};

export default emailjsConfig;
